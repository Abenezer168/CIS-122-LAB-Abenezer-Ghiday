﻿//Abenezer Ghiday
//10/21/22

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace NorthWindsS.Models
{
    public class Shipper
    {
        //class variables
        private int shipperId = -1;
        private string companyName = "n/a";
        private string phone = "n/a";

        //gets and sets
        // public properties
        // encapsulation
        public int ShipperId
        {
            get { return shipperId; }
            set
            {

                //must be greater than -1
                if (value > -1)
                {
                    shipperId = value;
                }
                else
                {
                    shipperId = 0;
                }
            }
        }
        public string CompanyName
        {
            get { return companyName; }
            set { companyName = value; }
        }
        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }

        public Shipper() : this(-1, "n/a", "n/a")

        {

            // Empty Constructor


        }
        // Methods
        public Shipper(int aShipperId, string aCompanyName, string aPhone)



        {

            ShipperId = aShipperId;
            CompanyName = aCompanyName;
            Phone = aPhone;


        }
        // Methods Go Here
        public override string ToString()
        {
            string message = "";
            message = message + "ShipperId: " + ShipperId + "\n";
            message = message + "CompanyName: " + CompanyName + "\n";
            message = message + "Phone" + Phone + "\n";
            return message;



        }

    }

}