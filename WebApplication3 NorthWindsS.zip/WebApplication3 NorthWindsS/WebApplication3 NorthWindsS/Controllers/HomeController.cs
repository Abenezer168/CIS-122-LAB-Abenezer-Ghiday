﻿
//Abenezer Ghiday
//10/21/22
using Microsoft.AspNetCore.Mvc;

using System;
using NorthWindsS.Models;

namespace NorthWindsS.Models
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            FileGateWay aGateway = new FileGateWay();



            List<Category> aListOfCategories = aGateway.GetCategory("C:\\Users\\abene\\Documents\\Categories.csv");
            ViewBag.ListOfCategories = aListOfCategories;


            List<Employee> aListOfEmployees = aGateway.GetEmployee("C:\\Users\\abene\\Documents\\Employees.csv");
            ViewBag.ListOfEmployees = aListOfEmployees;


            List<OrderDetail> aListOfOrderDetails = aGateway.GetOrderDetail("C:\\Users\\abene\\Documents\\OrderDetails.csv");
            ViewBag.ListOfOrderDetails = aListOfOrderDetails;


            List<Product> aListOfProducts = aGateway.GetProduct("C:\\Users\\abene\\Documents\\Products.csv");
            ViewBag.ListOfProducts = aListOfProducts;


            List<Shipper> aListOfShippers = aGateway.GetShipper("C:\\Users\\abene\\Documents\\Shippers.csv");
            ViewBag.ListOfShippers = aListOfShippers;


            List<Supplier> aListOfSuppliers = aGateway.GetSupplier("C:\\Users\\abene\\Documents\\Suppliers.csv");
            ViewBag.ListOfSuppliers = aListOfSuppliers;



            return View();



        }


    }
}
